import json
import boto3
from decimal import Decimal
from boto3.dynamodb.conditions import Attr

# DynamoDB connection
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("Kaviya-Cart")

# Convert Decimal values from DynamoDB to int
def decimal_default(obj):
    if isinstance(obj, Decimal):
        return int(obj)
    raise TypeError

# Common response format with CORS
def response(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS,DELETE"
        },
        "body": json.dumps(body, default=decimal_default)
    }

def lambda_handler(event, context):
    try:
        method = event.get("httpMethod")

        # -----------------------
        # GET CART
        # -----------------------
        if method == "GET":
            query_params = event.get("queryStringParameters") or {}
            user_id = int(query_params.get("user_id", 1))

            res = table.scan(
                FilterExpression=Attr("user_id").eq(user_id)
            )

            return response(200, res.get("Items", []))

        # -----------------------
        # ADD TO CART
        # -----------------------
        elif method == "POST":
            body = json.loads(event.get("body") or "{}")

            item = {
                "user_id": int(body.get("user_id", 1)),
                "product_id": int(body.get("product_id", 0)),
                "title": body.get("title", ""),
                "price": int(body.get("price", 0)),
                "qty": int(body.get("qty", 1))
            }

            table.put_item(Item=item)

            return response(200, {
                "message": "Added successfully",
                "item": item
            })

        # -----------------------
        # DELETE CART ITEM
        # -----------------------
        elif method == "DELETE":
            query_params = event.get("queryStringParameters") or {}
            user_id = int(query_params.get("user_id", 1))

            res = table.scan(
                FilterExpression=Attr("user_id").eq(user_id)
            )

            items = res.get("Items", [])

            for item in items:
                table.delete_item(
                    Key={
                        "user_id": item["user_id"]
                    }
                )

            return response(200, {
                "message": "Cart cleared successfully"
            })

        # -----------------------
        # INVALID METHOD
        # -----------------------
        else:
            return response(400, {
                "message": "Invalid request method"
            })

    except Exception as e:
        return response(500, {
            "error": str(e)
        })