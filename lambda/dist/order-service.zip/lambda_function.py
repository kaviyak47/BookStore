import json
import boto3
import uuid
from decimal import Decimal
from boto3.dynamodb.conditions import Attr

dynamodb = boto3.resource("dynamodb")

orders_table = dynamodb.Table("Kaviya-orders")
cart_table = dynamodb.Table("Kaviya-Cart")

def decimal_default(obj):
    if isinstance(obj, Decimal):
        return int(obj)
    raise TypeError

def response(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
        },
        "body": json.dumps(body, default=decimal_default)
    }

def lambda_handler(event, context):
    try:
        method = event.get("httpMethod")

        # PLACE ORDER
        if method == "POST":

            user_id = 1

            cart_items = cart_table.scan(
                FilterExpression=Attr("user_id").eq(user_id)
            ).get("Items", [])

            if not cart_items:
                return response(400, {"message": "Cart is empty"})

            total = sum(item["price"] * item["qty"] for item in cart_items)

            order = {
                "orderId": str(uuid.uuid4()),
                "user_id": user_id,
                "items": cart_items,
                "total": total
            }

            orders_table.put_item(Item=order)

            # clear cart after order
            for item in cart_items:
                cart_table.delete_item(
                    Key={
                        "user_id": item["user_id"],
                        "product_id": item["product_id"]
                    }
                )

            return response(200, {
                "message": "Order placed successfully",
                "order": order
            })

        # GET ORDERS
        elif method == "GET":
            res = orders_table.scan()

            return response(200, res.get("Items", []))

        return response(400, {"message": "Invalid request"})

    except Exception as e:
        return response(500, {"error": str(e)})